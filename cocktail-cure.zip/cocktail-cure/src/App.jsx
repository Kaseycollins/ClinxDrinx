import CocktailApp from "./components/CocktailApp";

function App() {
  return (
    <div className="App">
      <CocktailApp />
    </div>
  );
}

export default App;